const express=require('express');
//引入连接池模块
const pool=require('../pool.js');
//引入查询字符串模块
const querystring=require('querystring');
//console.log(pool);
//创建路由器对象
const r=express.Router();
r.post("/reg",(req,res)=>{
	var obj=req.body;
	var sql="insert into lvyou_user set ?";
	pool.query(sql,[obj],(err,result)=>{
		if(err) throw err;
		if(result.affectedRows>0){
			res.send("1");
		}else{
			res.send("0");
		}
	});
})
//导出路由器对象
module.exports=r;










